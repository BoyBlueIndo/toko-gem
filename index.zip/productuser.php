<?php
// include header.php file
include ('headeruser.php');
?>

<?php

    include ('Template/_productsuser.php');
  


    include ('Template/_top-sale.php');


?>

<?php


include ('footer.php');
?>

